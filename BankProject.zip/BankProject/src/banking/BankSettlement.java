//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

import java.util.HashMap;
import java.util.Map;

public interface BankSettlement {

	public void registerBank(Bank bk);
	public void unregisterBank(Bank bk);
	public void sendTransactions(BankPackage bkpkg);
	
}
