//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class History {

	private List<HistoryItem> historyItems = new ArrayList <HistoryItem>();
	
	public void addOperation(Operation o)
	{
		historyItems.add(o.getDetails());
	}
	
	public List<HistoryItem> getHistoryItems()
	{
		return historyItems;
	}
	
}
