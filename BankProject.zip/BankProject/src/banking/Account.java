//PUT - MIASI - 2017 - Daniel Szczurek - 96887

package banking;

public class Account implements AccountDecorator, BankProduct {
	
	private BankProductState acctState = null;
	private String acctNo = null;
    private double balance = 0.0;    
    private History history;

	public Account(String acctNo, double amount)
	{
		this.acctState = new BankProductIsOpen();
		this.acctNo = acctNo;
		this.balance = amount;
		this.history = new History();
		System.out.println("Bank account " + acctNo + " was opened");
	}
	
	@Override
	public String getAcctNo() 
	{
		return acctNo;
	}
	
	@Override
	public BankProductState getAcctState() {
		return acctState;
	}

	@Override
	public void setAcctState(BankProductState acctState) {
		this.acctState = acctState;
	}

	@Override
	public History getHistory()
	{
		return history;
	}

	@Override
	public double _getBalance() {
		return this.balance;
	}
	
	@Override
	public double getBalance() {
		return this.acctState.getBalance(this);
	}

	@Override
	public void _setBalance(double balance) {
		this.balance = balance;
	}
	
	@Override
	public void setBalance(double balance) {
		this.acctState.setBalance(this,balance);
	}

	@Override
	public void executeOperation (Operation o) {
		o.execute();	
		this.history.addOperation(o);
	}
	
	@Override
	public String description()
	{
		return "Bank account: " + this.acctNo;
	}

	@Override
	public void accept(Report r) {	
		r.visit(this);
	}
	
}
