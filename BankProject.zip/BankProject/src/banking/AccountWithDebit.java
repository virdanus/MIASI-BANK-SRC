//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public class AccountWithDebit implements AccountDecorator, BankProduct {
	
	private Account acct = null;
	private double limit = 0.0;	
    private double debit = 0.0;
   
	
	public AccountWithDebit(Account acct, double limit)
	{
		this.acct = acct;
		this.limit = limit;
		this.debit = limit;
	}
	
	@Override
	public String description() {
		return acct.description() + " with debit";
	}
	
	@Override
	public double getBalance() {
		return acct.getBalance();
	}

	@Override
	public double _getBalance() {
		return acct._getBalance();
	}

	@Override
	public void _setBalance(double balance) {
		acct._setBalance(balance);		
	}
	
	@Override
	public void setBalance(double amount) {
		
		if (debit + amount < 0)
		{
			System.out.println("Debit limit exceeded");
		} 
		else	
		{		
			acct.setBalance(amount);							
		}
	}

	@Override
	public BankProductState getAcctState() {
		return acct.getAcctState();
	}

	@Override
	public void setAcctState(BankProductState acctState) {
		acct.setAcctState(acctState);		
	}

	@Override
	public String getAcctNo() {
		return acct.getAcctNo();
	}

	@Override
	public History getHistory() {
		return acct.getHistory();
	}

	@Override
	public void executeOperation(Operation o) {
		acct.executeOperation(o);		
	}

	@Override
	public void accept(Report r) {
		acct.accept(r);
	}
	
}
