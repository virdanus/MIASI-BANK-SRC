//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public interface AccountDecorator {

	public double getBalance();
	public BankProductState getAcctState();
	public void setAcctState(BankProductState acctState);
	void setBalance(double amount);
	public String getAcctNo();
	public History getHistory();
	public void executeOperation (Operation o);
	public void accept(Report r);
	String description();
}