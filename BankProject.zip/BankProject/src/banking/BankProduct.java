//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public interface BankProduct {
	
	public BankProductState getAcctState();
	public void setAcctState(BankProductState acctState);
	public String getAcctNo();
	public double getBalance();
	public double _getBalance();
	public void setBalance(double balance);
	public void _setBalance(double balance);
	public String description();
	public History getHistory();
	public void executeOperation(Operation o);
	void accept(Report r);	
}
