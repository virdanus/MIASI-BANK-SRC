//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

import java.util.HashMap;
import java.util.Map;

public class BankSettlementCenter implements BankSettlement {
	
	String bscName = null;
	private final Map<String, Bank> banksStore = new HashMap<String, Bank>();

	public BankSettlementCenter(String bscName) {
		super();
		this.bscName = bscName;
	}

	@Override
	public void registerBank(Bank bk) 
	{
		banksStore.put(bk.getBankID(),bk);
	}
	
	@Override
	public void unregisterBank(Bank bk) {
		banksStore.remove(bk.getBankID());		
	} 

	@Override
	public void sendTransactions(BankPackage bkpkg) 
	{
		
	    String fromBankAcctNo = bkpkg.getFromBankAcctNo();	
	    String fromBankNo = fromBankAcctNo.substring(0, 10);
	    Bank fromBank = null;
	    
	    String toBankAcctNo = bkpkg.getToBankAcctNo();
	    String toBankNo = toBankAcctNo.substring(0, 10);
	    String _toBankNo = null;
	    Bank _toBank = null;
	    
	    boolean acctFound = false;
	    boolean bankFound = false;
		
		for (Map.Entry<String, Bank> entry : banksStore.entrySet()) {
			
		    _toBankNo = entry.getKey();
		    _toBank = entry.getValue();
		    
		    if (_toBankNo.equals(toBankNo))
		    {
		    	bankFound = true;
		    	acctFound = _toBank.handleInterBankTransfer(fromBankAcctNo, toBankAcctNo, bkpkg.getAmount(),bankFound);
		    }
		    
		    if (_toBankNo.equals(fromBankNo))
		    {
		    	fromBank = entry.getValue();
		    }
		}
		
		if(!acctFound)
		{
			acctFound = fromBank.handleInterBankTransfer(toBankAcctNo, fromBankAcctNo, bkpkg.getAmount(),acctFound);
		}

	}

	

}
