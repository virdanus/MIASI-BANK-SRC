//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

import java.util.List;

public class ReportingHistory<T> {

	private List<T> t;
	private boolean isCompleted = false;
	
	public ReportingHistory(List<T> t) {
		this.t = t;
	}

	public void listHistory()
	{
		t.forEach(e -> System.out.println(e.toString()));
		this.isCompleted = true;
	}

	public boolean isCompleted() {
		return isCompleted;
	}

	
}
