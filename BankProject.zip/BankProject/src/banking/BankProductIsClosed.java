//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public class BankProductIsClosed implements BankProductState {
	
	String msg = "This product is closed";


	@Override
	public double getBalance(BankProduct bp) {
		System.out.println(msg);
		return bp._getBalance();
	}

	@Override
	public void setBalance(BankProduct bp, double balance) {
		System.out.println(msg);		
	}

}
