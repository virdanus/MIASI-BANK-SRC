//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public class Main {

	public static void main(String[] args) {
		
		//BANK NUMBER - ACCOUNT NUMBER
		//XXXXXXXXXX-XXXXXXXXXXXXXXXX
		//0024901044-0000320094007370
		//0024900005-0000456698892694
		//0015401056-2069500008040001
		
		System.out.println("BANK APPLICATION");
		
		BankSettlementCenter bscKIR = new BankSettlementCenter("KIR");
		
		Bank bankA = new Bank("0024901044","WBK");
		bankA.setBSC(bscKIR);
		bankA.registerBankAtBSC();
		
		Bank bankB = new Bank("0024900005","PKO");
		bankB.setBSC(bscKIR);
		bankB.registerBankAtBSC();
		
		bankA.openAccount("0000320094007370",100);
		bankA.openAccount("0000320094007371",1000);
		bankA.openLoan("0000320094007372",700, 0.21, 2);
		bankA.openSavings("0000320094007373",100, 0.05, 1);
		
		Savings acctS = (Savings) bankA.getProduct("0000320094007373");
		System.out.println(acctS.getBalance());
		
		bankB.openAccount("0000456698892694",500);
		
		bankA.listProducts();
		bankB.listProducts();
		
		Account acctA1 = (Account) bankA.getProduct("0000320094007370");
	    //bankA.closeProduct(acctA1);
		Account acctA2 = (Account) bankA.getProduct("0000320094007371");
		
		Account acctB1 = (Account) bankB.getProduct("0000456698892694");
		
		Loan acctL1 = (Loan) bankA.getProduct("0000320094007372");
		
		BankProduct acctWithDebit = new AccountWithDebit(acctA1,400);
		bankA.withdraw(acctWithDebit , 100);
		
		bankA.interestsOnLoan(acctL1);
		
		bankA.payInstallment(acctL1, 20);
			
		bankA.withdraw(acctA1,800);
		
		bankA.internalTransfer(acctA1, acctA2, 2);
		
		ReportingHistory<HistoryItem> report1 = new ReportingHistory<HistoryItem>(acctA1.getHistory().getHistoryItems());
		ReportingHistory<HistoryItem> report2 = new ReportingHistory<HistoryItem>(acctL1.getHistory().getHistoryItems());
		
		report1.listHistory();
		report2.listHistory();
		
		BankProduct acctWithDebit2 = new AccountWithDebit(acctA1,200);
		bankA.withdraw(acctWithDebit2 , 400);
		
		//bankA.closeProduct(acctA1);
		
		System.out.println(acctWithDebit.description());
		
	    bankA.interBankTransfer(acctA1, "00249000050000456698892694", 35);	    
	    
	    ReportingHistory<HistoryItem> report3 = new ReportingHistory<HistoryItem>(acctA1.getHistory().getHistoryItems());
	    report3.listHistory();
	    
	    TotalBankAssets bs1 = new TotalBankAssets();
	    
	    bankA.accept(bs1);
	    
	    TotalBankAssets bs2 = new TotalBankAssets();
	    bankB.accept(bs2);
	}

}
