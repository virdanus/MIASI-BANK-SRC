//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Withdraw implements Operation {
	
	double amount = 0.0;
	BankProduct acct = null;
	long timestamp = 0; 
	
	public Withdraw(BankProduct acct, double amount)
	{
		this.acct = acct;
		this.amount = amount;
	}

	@Override
	public void execute() {
				
		acct.setBalance(acct.getBalance() - amount);
		timestamp = System.currentTimeMillis();
	}

	@Override
	public HistoryItem getDetails() {
		
		return new HistoryItem(timestamp,acct.getAcctNo(),"", "Withdraw", amount, acct.getBalance());
	}

}
