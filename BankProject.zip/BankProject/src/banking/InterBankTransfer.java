//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public class InterBankTransfer implements Operation {
	
	double amount = 0.0;
	BankProduct acct = null;
	long timestamp = 0; 
	

	public InterBankTransfer(BankProduct acctTo, double amount)
	{
		this.acct = acctTo;
		this.amount = amount;
	}

	@Override
	public void execute() {
	
		if (amount < 0)
		{
			acct.setBalance(acct.getBalance() - amount);
		} else
		{
			acct.setBalance(acct.getBalance() + amount);
		}	
		
		timestamp = System.currentTimeMillis();
	}

	@Override
	public HistoryItem getDetails() {
		return new HistoryItem(timestamp,acct.getAcctNo(),"","Interbank Transfer",amount,acct.getBalance());
	}

}
