//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

import java.util.HashMap;
import java.util.Map;

public class Bank {
	
	private BankSettlement bsc;
	private String bankName;
	private String bankID;	
	private Map <String,BankProduct> products = null;
	
	public String getBankID() {
		return bankID;
	}
	
	public String getBankName() {
		return bankName;
	}

	public Bank(String bankID, String bankName)
	{
		this.bankID = bankID;
		this.bankName = bankName;
		products = new HashMap<String,BankProduct>();
		System.out.println("Bank " + bankName + " was opened");
	}
	
	public BankProduct getProduct(String acctNo) {
		
		return products.get(acctNo);
	}

	public void openAccount(String acctNo, double amount)
	{
		Account acct = (Account) products.get(acctNo);
		
		if(acct == null)
		{
		    acct = new Account(acctNo, amount);
		}
		
		products.put(acctNo, acct);
	}
	
	public void openLoan(String acctNo, double amount, double rate, int period)
	{
		Loan acct = (Loan) products.get(acctNo);
		
		if(acct == null)
		{
		    acct = new Loan(acctNo, amount, rate, period);
		}
		
		products.put(acctNo, acct);
	}
	
	public void openSavings(String acctNo, double amount, double rate, int period)
	{
		Savings acct = (Savings) products.get(acctNo);
		
		if(acct == null)
		{
		    acct = new Savings(acctNo, amount, rate, period);
		}
		
		products.put(acctNo, acct);
	}
	
	public void closeProduct(BankProduct bp)
	{
		bp.setAcctState(new BankProductIsClosed());
	}
	
	public void listProducts()
	{
		for(BankProduct bp: products.values())
		{
			System.out.println(bp.description());
		}
	}
	
	public boolean handleInterBankTransfer(String fromBankAcctNo, String toBankAcctNo, double amount, boolean successFlag)
	{	
		
		String toAcctNo = toBankAcctNo.substring(10,26);			
		BankProduct toAcct = products.get(toAcctNo);
		
		if (successFlag)
		{		
			if (toAcct != null)
			{
				Operation o = new InterBankTransfer(toAcct,amount);
				toAcct.executeOperation(o);				
				successFlag = true;
				
			} else
			{
				successFlag = false;
			}	
			
		} else
		{
			if (toAcct != null)
			{
				Operation o = new Deposit(toAcct,amount);
				toAcct.executeOperation(o);				
				successFlag = true;
				
			} else
			{
				successFlag = false;
			}	
		}
					
		return successFlag;
	}
	
	public void interBankTransfer(BankProduct fromAcct, String toBankAcctNo, double amount)
	{		
		String fromAcctNo = fromAcct.getAcctNo();
		String fromBankAcctNo = this.getBankID().concat(fromAcctNo);
		
		Operation o = new Withdraw(fromAcct, amount);
		fromAcct.executeOperation(o);
		
		BankPackage bkpkg = new BankPackage(fromBankAcctNo,toBankAcctNo,amount);
		bsc.sendTransactions(bkpkg);
	}
	
	public void internalTransfer(BankProduct fromAcct, BankProduct toAcct, double amount)
	{		
		Operation o = new Transfer(fromAcct,toAcct,amount);
		fromAcct.executeOperation(o);
	}
	
	public void withdraw(BankProduct acct, double amount)
	{	
		Operation o = new Withdraw(acct, amount);
		acct.executeOperation(o);
	}
	
	public void deposit(BankProduct acct, double amount)
	{	
		Operation o = new Deposit(acct, amount);
		acct.executeOperation(o);
	}
	
	public void payInstallment(Loan acct, double amount)
	{	
		Operation o = new Installment(acct, amount);
		acct.executeOperation(o);
	}
	
	public void interestsOnSavings(Savings acct)
	{	
		Operation o = new InterestsOnSavings(acct);
		acct.executeOperation(o);
	}
	
	public void interestsOnLoan(Loan acct)
	{	
		Operation o = new InterestsOnLoan(acct);
		acct.executeOperation(o);
	}
	
	public void setBSC(BankSettlement bsc)
	{
		this.bsc = bsc;	
	}
	
	public void registerBankAtBSC()
	{
		bsc.registerBank(this);
	}
	
	public Map <String,BankProduct> getBankProducts()
	{
	   return this.products;
	}

	public void accept(Report r)
	{
		for (Map.Entry<String,BankProduct> entry : products.entrySet()) {
		
		    BankProduct product = entry.getValue();
		    product.accept(r);
		}
		
		r.visit(this);
	}	
}
