//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public class Loan implements BankProduct {
	
	private BankProductState acctState = null;
	private String acctNo = null;
	private double principal = 0.0;
	private double interests = 0.0;
	private double balance = 0.0;
	private double rate = 0.0;
	private double period = 0.0;
	private History history;

	public Loan(String acctNo, double amount, double rate, int period) {
		this.acctState = new BankProductIsOpen();
		this.acctNo = acctNo;
		this.principal = amount;
		this.balance = -amount;
		this.rate = rate;
		this.period = period;
		this.history = new History();
		System.out.println("Loan account " + acctNo + " was opened");
	}
	
	@Override
	public BankProductState getAcctState() {
		return acctState;
	}
	
	@Override
	public void setAcctState(BankProductState savingsState) {
		this.acctState = savingsState;
	}
	
	@Override
	public String getAcctNo() {
		return acctNo;
	}
	
	@Override
	public double _getBalance() {
		return balance;
	}

	@Override
	public double getBalance() {
		return this.acctState.getBalance(this);
	}

	@Override
	public void setBalance(double balance) {
		this.acctState.setBalance(this,balance);
	}
	
	@Override
	public void _setBalance(double balance) {
		this.balance = balance;		
	}
	
	@Override
	public void executeOperation (Operation o) {
		o.execute();	
		this.history.addOperation(o);
	}

	@Override
	public String description() {	
		return "Loan account: " + this.acctNo;
	}

	@Override
	public void accept(Report r) {
		r.visit(this);		
	}

	@Override
	public History getHistory()
	{
		return history;
	}
	
	public double getPrincipal() {
		return principal;
	}
	
	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public double getPeriod() {
		return period;
	}

	public void setPeriod(double period) {
		this.period = period;
	}

	public double getInterests() {
		return interests;
	}

	public void setInterests(double interests) {
		this.interests = interests;
	}	
	
	
}
