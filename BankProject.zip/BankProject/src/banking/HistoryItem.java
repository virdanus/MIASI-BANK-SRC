//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public class HistoryItem {
	
	private long timestamp = 0;
	private String fromAcctNo = null;
	private String toAcctNo = null;
	private String operation = null;
	private double amount = 0;
	private double balance = 0;
	
	public HistoryItem() {
		super();
	}

	public HistoryItem(long timestamp,String fromAcctNo,String toAcctNo, String operation, double amount, double balance)
	{
		this.timestamp = timestamp;
		this.fromAcctNo = fromAcctNo;
		this.toAcctNo = toAcctNo;
		this.operation = operation;
		this.amount = amount;
		this.balance = balance;
	}
	
	public String toString()
	{
		return "History(" + this.timestamp + "): " + "From -> " + this.fromAcctNo + " To -> " + this.toAcctNo + " " +  
				this.operation + " " + this.amount + " Balance: " + this.balance;
		
	}

}
