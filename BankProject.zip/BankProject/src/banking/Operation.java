//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public interface Operation {

	public void execute();	
	public HistoryItem getDetails();
}
