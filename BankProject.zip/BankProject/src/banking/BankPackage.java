//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public class BankPackage {

	private String fromBankAcctNo;
	private String toBankAcctNo;
	private double amount;
	
	
	public BankPackage(String fromBankAcctNo, String toBankAcctNo, double amount) {
		super();
		this.fromBankAcctNo = fromBankAcctNo;
		this.toBankAcctNo = toBankAcctNo;
		this.amount = amount;
	}
	
	public void setFromBankAcctNo(String fromBankAcctNo) {
		this.fromBankAcctNo = fromBankAcctNo;
	}

	public String getFromBankAcctNo() {
		return fromBankAcctNo;
	}
	public String getToBankAcctNo() {
		return toBankAcctNo;
	}

	public double getAmount() {
		return amount;
	}
}
