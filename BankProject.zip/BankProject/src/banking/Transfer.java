//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public class Transfer implements Operation {
	
	double amount = 0;
	BankProduct acctFrom = null;
	BankProduct acctTo = null;
	long timestamp = 0;
	

	public Transfer(BankProduct acctFrom, BankProduct acctTo, double amount)
	{
		this.acctFrom = acctFrom;
		this.acctTo = acctTo;
		this.amount = amount;
	}

	@Override
	public void execute() {
		
		acctFrom.setBalance(acctFrom.getBalance() - amount);
		acctTo.setBalance(acctTo.getBalance() + amount);
		timestamp = System.currentTimeMillis();		
	}

	@Override
	public HistoryItem getDetails() {
		return new HistoryItem(timestamp,this.acctFrom.getAcctNo(),this.acctTo.getAcctNo(),"Transfer",amount,this.acctFrom.getBalance());
	}

}
