//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public class InterestsOnSavings implements Operation {
	
	Savings acct = null;
	double amount = 0.0;
	long timestamp = 0; 

	public InterestsOnSavings(Savings acct) {
		this.acct = acct;
	}

	@Override
	public void execute() {
		this.amount = Math.pow((1 + acct.getRate()),acct.getPeriod());
		acct.setBalance(acct.getBalance() * this.amount); 	
		acct.setInterests(acct.getInterests() + this.amount);
		timestamp = System.currentTimeMillis();
	}

	@Override
	public HistoryItem getDetails() {
		return new HistoryItem(timestamp,acct.getAcctNo(),"", "Interests on savings", amount, acct.getBalance());
	}

}
