//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public interface BankProductState {

	
	public double getBalance(BankProduct bp);
	public void setBalance(BankProduct bp, double balance);
		
}
