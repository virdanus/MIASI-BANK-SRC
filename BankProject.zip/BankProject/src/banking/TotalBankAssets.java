//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

import java.util.Map;

public class TotalBankAssets implements Report {
	
	double total = 0;

	@Override
	public void visit(Account acct) {		
		System.out.println(acct.description() + " with the balance " + acct.getBalance());	
	}

	@Override
	public void visit(Loan acct) {
		System.out.println(acct.description() + " with the balance " + acct.getBalance());			
	}

	@Override
	public void visit(Savings acct) {
		System.out.println(acct.description() + " with the balance " + acct.getBalance());			
	}

	@Override
	public void visit(Bank bank) {
		
		Map <String,BankProduct> products = bank.getBankProducts();

		for (Map.Entry<String,BankProduct> entry : products.entrySet()) {
			
		    total += entry.getValue().getBalance();

		}		
		System.out.println("Total assets: " + total);					
	}

	public double getTotal() {
		return total;
	}	
}
