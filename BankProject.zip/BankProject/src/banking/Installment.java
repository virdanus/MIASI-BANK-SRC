//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public class Installment implements Operation {
	
	double amount = 0.0;
	BankProduct acct = null;
	long timestamp = 0; 
	
	
	public Installment(BankProduct acct, double amount)
	{
		this.acct = acct;
		this.amount = amount;
	}

	@Override
	public void execute() {				
		acct.setBalance(acct.getBalance() + amount);
		timestamp = System.currentTimeMillis();
	}

	@Override
	public HistoryItem getDetails() {
		
		return new HistoryItem(timestamp,acct.getAcctNo(),"", "Installment", amount, acct.getBalance());
	}

}
