//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public class BankProductIsOpen implements BankProductState {
		
	public BankProductIsOpen() 
	{
		super();
	}

	@Override
	public double getBalance(BankProduct bp)
	{
		return bp._getBalance();
	}

	@Override
	public void setBalance(BankProduct bp, double balance)
	{
		bp._setBalance(balance);
	}


}
