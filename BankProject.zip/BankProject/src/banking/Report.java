//PUT - MIASI - 2017 - Daniel Szczurek - 96887
package banking;

public interface Report {

	void visit(Account acct);
	void visit(Loan acct);
	void visit(Savings acct);
	void visit(Bank bank);
}
