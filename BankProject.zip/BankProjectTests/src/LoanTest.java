//PUT - MIASI - 2017 - Daniel Szczurek - 96887
import org.junit.Test;
import banking.*;
import static org.junit.Assert.*;
import org.junit.Before;

public class LoanTest {
	
	private Bank bank = null;
	private Loan acctL = null;

	
    @Before
    public void Before() {
    	
    	bank = new Bank("0024901044","WBK");
    	bank.openLoan("0000320094007372",100, 0.20, 1);
		
		acctL = (Loan) bank.getProduct("0000320094007372");
    }
	
	@Test
	public void LoanBalanceWithAMinusHundred()
	{	
		assertEquals("Balance was not -100",-100,acctL.getBalance(),0.01);
	}
	
	@Test
	public void BalanceAfterInterestOnALoan()
	{
		bank.interestsOnLoan(acctL);		
		assertEquals("Balance was not -120",-120,acctL.getBalance(),0.01);
	}
	
	@Test
	public void LoanBalanceAfterInstallmentOfThirty()
	{
		bank.payInstallment(acctL, 30);		
		assertEquals("Balance was not -70",-70,acctL.getBalance(),0.01);
	}
	
	@Test
	public void LoanValueAfterItIsPaidOff()
	{
		bank.interestsOnLoan(acctL);	
		assertEquals("Balance was not 120",120,acctL.getPrincipal() + acctL.getInterests(),0.01);
	}


}
