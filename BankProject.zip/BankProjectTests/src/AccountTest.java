//PUT - MIASI - 2017 - Daniel Szczurek - 96887
import org.junit.Test;
import banking.*;
import static org.junit.Assert.*;
import org.junit.Before;

public class AccountTest {
	
	private Bank bank = null;
	private Account acct1 = null;
	private Account acct2 = null;
	
    @Before
    public void Before() {
    	
    	bank = new Bank("0024901044","WBK");
    	
		bank.openAccount("0000320094007370",100);
		bank.openAccount("0000320094007371",1000);
		
		acct1 = (Account) bank.getProduct("0000320094007370");
		acct2 = (Account) bank.getProduct("0000320094007371");
    }
	
	@Test
	public void ExistingAccountBalanceWithAHundred()
	{	
		assertEquals("Balance was not 100",100,acct1.getBalance(),0.01);
	}
	
	@Test
	public void ExistingAccountBalanceAfterWithdrawalOfFifty()
	{
		bank.withdraw(acct1,50);		
		assertEquals("Balance was not 50",50,acct1.getBalance(),0.01);
	}
	
	@Test
	public void WithdrawFromClosedAccount()
	{
		bank.closeProduct(acct1);
		bank.withdraw(acct1,50);		
		assertEquals("Balance was not 100",100,acct1.getBalance(),0.01);
	}
	
	@Test
	public void ExistingAccountBalanceAfterDepositOfTwenty()
	{
		bank.deposit(acct1,20);		
		assertEquals("Balance was not 120",120,acct1.getBalance(),0.01);
	}
	
	@Test
	public void ExistingAccountBalanceAfterTransferOfTen()
	{		
		bank.internalTransfer(acct1, acct2, 10);		
		assertEquals("Balance was not 90",90,acct1.getBalance(),0.01);
	}

}
