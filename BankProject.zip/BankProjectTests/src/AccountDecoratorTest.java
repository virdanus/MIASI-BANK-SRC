//PUT - MIASI - 2017 - Daniel Szczurek - 96887
import org.junit.Test;
import banking.*;
import static org.junit.Assert.*;
import org.junit.Before;

public class AccountDecoratorTest {
	
	private Bank bank = null;
	private Account acct1 = null;
	private Account acct2 = null;
	private BankProduct acctWithDebit = null;
	
    @Before
    public void Before() {
    	
    	bank = new Bank("0024901044","WBK");
    	
		bank.openAccount("0000320094007370",100);
		bank.openAccount("0000320094007371",1000);
		
		acct1 = (Account) bank.getProduct("0000320094007370");
		acct2 = (Account) bank.getProduct("0000320094007371");
		
		acctWithDebit = new AccountWithDebit(acct1,400);
    }
	
	@Test
	public void BalanceOnAccountWithDebit()
	{		
		assertEquals("Balance was not 100",100,acctWithDebit.getBalance(),0.01);
	}
	
	@Test
	public void WithdrawTwoHundredOnAccountWithFourHundredDebit()
	{		
		bank.withdraw(acctWithDebit, 200);
		assertEquals("Balance was not -100",-100,acctWithDebit.getBalance(),0.01);
	}
	
	@Test
	public void WithdrawSixHundredOnAccountWithFourHundredDebit()
	{		
		bank.withdraw(acctWithDebit, 600);
		assertEquals("Balance was not 100",100,acctWithDebit.getBalance(),0.01);
	}
	
	@Test
	public void WithdrawHundredOnAccountWithFourHundredDebit()
	{		
		bank.withdraw(acctWithDebit, 100);
		assertEquals("Balance was not 0",0,acctWithDebit.getBalance(),0.01);
	}

}
