//PUT - MIASI - 2017 - Daniel Szczurek - 96887
import org.junit.Test;
import banking.*;
import static org.junit.Assert.*;
import org.junit.Before;

public class SavingsTest {
	
	private Bank bank = null;
	private Savings acctS = null;

	
    @Before
    public void Before() {
    	
    	bank = new Bank("0024901044","WBK");
    	bank.openSavings("0000320094007373",100, 0.05, 1);
		
		acctS = (Savings) bank.getProduct("0000320094007373");
    }
	
	@Test
	public void SavingsBalanceWithAHundred()
	{	
		assertEquals("Balance was not 100",100,acctS.getBalance(),0.01);
	}
	
	@Test
	public void BalanceAfterInterestOnSavings()
	{
		bank.interestsOnSavings(acctS);		
		assertEquals("Balance was not 105",105,acctS.getBalance(),0.01);
	}


}
