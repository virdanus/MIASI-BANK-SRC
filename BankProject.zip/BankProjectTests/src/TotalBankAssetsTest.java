//PUT - MIASI - 2017 - Daniel Szczurek - 96887
import org.junit.Test;
import banking.*;
import static org.junit.Assert.*;
import org.junit.Before;

public class TotalBankAssetsTest {
	
	private Bank bank = null;
	private Account acct1 = null;
	private Account acct2 = null;
	private Loan acctL = null;
	private Savings acctS = null;
	private TotalBankAssets tba = null;
	
    @Before
    public void Before() {
    	
    	bank = new Bank("0024901044","WBK");
    	
		bank.openAccount("0000320094007370",100);
		bank.openAccount("0000320094007371",1000);
		bank.openLoan("0000320094007372",100, 0.20, 1);
		bank.openSavings("0000320094007373",100, 0.05, 1);
		
		acct1 = (Account) bank.getProduct("0000320094007370");
		acct2 = (Account) bank.getProduct("0000320094007371");	
		acctL = (Loan) bank.getProduct("0000320094007372");		
		acctS = (Savings) bank.getProduct("0000320094007373");
		
		bank.withdraw(acct1,50);
		bank.deposit(acct2,20);	
		bank.interestsOnLoan(acctL);
		bank.interestsOnSavings(acctS);	
		
		tba = new TotalBankAssets();
    }
	
	@Test
	public void TotalAssetsOfTheBankOneThousandFiftyFive()
	{	
		bank.accept(tba);
		assertEquals("Total assets were not 1055",1055,tba.getTotal(),0.01);
	}

}
