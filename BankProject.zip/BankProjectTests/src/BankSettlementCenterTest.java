//PUT - MIASI - 2017 - Daniel Szczurek - 96887
import org.junit.Test;
import banking.*;
import static org.junit.Assert.*;
import org.junit.Before;


public class BankSettlementCenterTest {
	
	private BankSettlementCenter bscKIR = null;
	private Bank bankA = null;
	private Bank bankB = null;
	private Account acctA1 = null;
	private Account acctB1 = null;
	
    @Before
    public void Before() {
    	
		//BANK NUMBER - ACCOUNT NUMBER
		//XXXXXXXXXX-XXXXXXXXXXXXXXXX
    	
    	bscKIR = new BankSettlementCenter("KIR");
    	
    	bankA = new Bank("0024901044","WBK");
		bankA.setBSC(bscKIR);
		bankA.registerBankAtBSC();
    	
    	bankB = new Bank("0024900005","PKO");
		bankB.setBSC(bscKIR);
		bankB.registerBankAtBSC();
		
		bankA.openAccount("0000320094007370",150);
		bankB.openAccount("0000456698892694",500);
		
		acctA1 = (Account) bankA.getProduct("0000320094007370");
		acctB1 = (Account) bankB.getProduct("0000456698892694");
    }
	
	@Test
	public void InterBankTransferOfFifty()
	{	
		bankA.interBankTransfer(acctA1, "00249000050000456698892694",50);	
		assertEquals("Balance was not 100",100,acctA1.getBalance(),0.01);
		assertEquals("Balance was not 550",550,acctB1.getBalance(),0.01);
	}
	
	@Test
	public void InterBankTransferBankNotRegisteredAtBSC()
	{	
		bscKIR.unregisterBank(bankB);
		bankA.interBankTransfer(acctA1, "00249000050000456698892694",50);	
		assertEquals("Balance was not 150",150,acctA1.getBalance(),0.01);
		assertEquals("Balance was not 500",500,acctB1.getBalance(),0.01);
	}
	
	@Test
	public void InterBankTransferBankAccountNotFound()
	{	
		bankA.interBankTransfer(acctA1, "00249000050000456698892699",50);	
		assertEquals("Balance was not 150",150,acctA1.getBalance(),0.01);
		assertEquals("Balance was not 500",500,acctB1.getBalance(),0.01);
	}

}
