//PUT - MIASI - 2017 - Daniel Szczurek - 96887
import org.junit.Test;
import banking.*;
import static org.junit.Assert.*;
import org.junit.Before;

public class HistoryTest {
	
	private Bank bank = null;
	private Account acct1 = null;
	private Account acct2 = null;
	ReportingHistory<HistoryItem> rh = null;
	
    @Before
    public void Before() throws InterruptedException {
    	
    	bank = new Bank("0024901044","WBK");
    	
		bank.openAccount("0000320094007370",100);
		bank.openAccount("0000320094007371",1000);
		
		acct1 = (Account) bank.getProduct("0000320094007370");
		acct2 = (Account) bank.getProduct("0000320094007371");	
		
		bank.withdraw(acct1,50);
		Thread.sleep(10);
		bank.internalTransfer(acct1, acct2, 10);	
		
	    rh = new ReportingHistory<HistoryItem>(acct1.getHistory().getHistoryItems());
	    
    }
	
	@Test
	public void ReportingTransactionHistory()
	{	
		rh.listHistory();
		assertEquals("History report was not completed",true,rh.isCompleted());	
	}

}
