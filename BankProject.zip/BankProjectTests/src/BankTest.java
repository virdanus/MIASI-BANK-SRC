//PUT - MIASI - 2017 - Daniel Szczurek - 96887
import org.junit.Test;
import banking.*;
import static org.junit.Assert.*;
import org.junit.Before;

public class BankTest {
	
	private Bank bank = null;
	private Account acct1 = null;
	private Account acct2 = null;
	
    @Before
    public void Before() {
    	
    	bank = new Bank("0024901044","WBK");
    	
		bank.openAccount("0000320094007370",100);
		bank.openAccount("0000320094007371",1000);
		
		acct1 = (Account) bank.getProduct("0000320094007370");
		acct2 = (Account) bank.getProduct("0000320094007371");
    }
	
	@Test
	public void InternalTransferOfTen()
	{
		bank.internalTransfer(acct1, acct2, 10);		
		assertEquals("Balance was not 90",90,acct1.getBalance(),0.01);
		assertEquals("Balance was not 1010",1010,acct2.getBalance(),0.01);
	}
}
